package com.materialless.leobookapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
